
/* GUI option: FLTK */
#undef GUI_FLTK
#undef FLTK_FLASHING
#undef FLTK_RELEVANT

/* GUI option: GTK */
#undef GUI_GTK
#undef GTK_RELEVANT

/* speed options */
#undef SPEED_FULL
#undef SPEED_FREAL
#undef SPEED_REAL

/* SNAP file name */
#undef SNAPFILE

/* ROM file name */
#undef ROMFILE

/* Version number of package */
#undef VERSION


