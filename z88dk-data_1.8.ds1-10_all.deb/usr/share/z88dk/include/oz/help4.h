/*
 *      Help File for Commands in Topic 4
 *
 *      Don't include yourself!!!
 */


#ifdef TOPIC4_1HELP1
.in_com_hlp4_1
        defb    $7F
        HELPTEXT(TOPIC4_1HELP1)
#ifdef TOPIC4_1HELP2
        HELPTEXT(TOPIC4_1HELP2)
#endif
#ifdef TOPIC4_1HELP3
        HELPTEXT(TOPIC4_1HELP3)
#endif
#ifdef TOPIC4_1HELP4
        HELPTEXT(TOPIC4_1HELP4)
#endif
#ifdef TOPIC4_1HELP5
        HELPTEXT(TOPIC4_1HELP5)
#endif
#ifdef TOPIC4_1HELP6
        HELPTEXT(TOPIC4_1HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_1HELP1 - overall  */

#ifdef TOPIC4_2HELP1
.in_com_hlp4_2
        defb    $7F
        HELPTEXT(TOPIC4_2HELP1)
#ifdef TOPIC4_2HELP2
        HELPTEXT(TOPIC4_2HELP2)
#endif
#ifdef TOPIC4_2HELP3
        HELPTEXT(TOPIC4_2HELP3)
#endif
#ifdef TOPIC4_2HELP4
        HELPTEXT(TOPIC4_2HELP4)
#endif
#ifdef TOPIC4_2HELP5
        HELPTEXT(TOPIC4_2HELP5)
#endif
#ifdef TOPIC4_2HELP6
        HELPTEXT(TOPIC4_2HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_2HELP1 - overall  */


#ifdef TOPIC4_3HELP1
.in_com_hlp4_3
        defb    $7F
        HELPTEXT(TOPIC4_3HELP1)
#ifdef TOPIC4_3HELP2
        HELPTEXT(TOPIC4_3HELP2)
#endif
#ifdef TOPIC4_3HELP3
        HELPTEXT(TOPIC4_3HELP3)
#endif
#ifdef TOPIC4_3HELP4
        HELPTEXT(TOPIC4_3HELP4)
#endif
#ifdef TOPIC4_3HELP5
        HELPTEXT(TOPIC4_3HELP5)
#endif
#ifdef TOPIC4_3HELP6
        HELPTEXT(TOPIC4_3HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_3HELP1 - overall  */




#ifdef TOPIC4_4HELP1
.in_com_hlp4_4
        defb    $7F
        HELPTEXT(TOPIC4_4HELP1)
#ifdef TOPIC4_4HELP2
        HELPTEXT(TOPIC4_4HELP2)
#endif
#ifdef TOPIC4_4HELP3
        HELPTEXT(TOPIC4_4HELP3)
#endif
#ifdef TOPIC4_4HELP4
        HELPTEXT(TOPIC4_4HELP4)
#endif
#ifdef TOPIC4_4HELP5
        HELPTEXT(TOPIC4_4HELP5)
#endif
#ifdef TOPIC4_4HELP6
        HELPTEXT(TOPIC4_4HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_4HELP1 - overall  */


#ifdef TOPIC4_5HELP1
.in_com_hlp4_5
        defb    $7F
        HELPTEXT(TOPIC4_5HELP1)
#ifdef TOPIC4_5HELP2
        HELPTEXT(TOPIC4_5HELP2)
#endif
#ifdef TOPIC4_5HELP3
        HELPTEXT(TOPIC4_5HELP3)
#endif
#ifdef TOPIC4_5HELP4
        HELPTEXT(TOPIC4_5HELP4)
#endif
#ifdef TOPIC4_5HELP5
        HELPTEXT(TOPIC4_5HELP5)
#endif
#ifdef TOPIC4_5HELP6
        HELPTEXT(TOPIC4_5HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_5HELP1 - overall  */


#ifdef TOPIC4_6HELP1
.in_com_hlp4_6
        defb    $7F
        HELPTEXT(TOPIC4_6HELP1)
#ifdef TOPIC4_6HELP2
        HELPTEXT(TOPIC4_6HELP2)
#endif
#ifdef TOPIC4_6HELP3
        HELPTEXT(TOPIC4_6HELP3)
#endif
#ifdef TOPIC4_6HELP4
        HELPTEXT(TOPIC4_6HELP4)
#endif
#ifdef TOPIC4_6HELP5
        HELPTEXT(TOPIC4_6HELP5)
#endif
#ifdef TOPIC4_6HELP6
        HELPTEXT(TOPIC4_6HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_6HELP1 - overall  */


#ifdef TOPIC4_7HELP1
.in_com_hlp4_7
        defb    $7F
        HELPTEXT(TOPIC4_7HELP1)
#ifdef TOPIC4_7HELP2
        HELPTEXT(TOPIC4_7HELP2)
#endif
#ifdef TOPIC4_7HELP3
        HELPTEXT(TOPIC4_7HELP3)
#endif
#ifdef TOPIC4_7HELP4
        HELPTEXT(TOPIC4_7HELP4)
#endif
#ifdef TOPIC4_7HELP5
        HELPTEXT(TOPIC4_7HELP5)
#endif
#ifdef TOPIC4_7HELP6
        HELPTEXT(TOPIC4_7HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_7HELP1 - overall  */


#ifdef TOPIC4_8HELP1
.in_com_hlp4_8
        defb    $7F
        HELPTEXT(TOPIC4_8HELP1)
#ifdef TOPIC4_8HELP2
        HELPTEXT(TOPIC4_8HELP2)
#endif
#ifdef TOPIC4_8HELP3
        HELPTEXT(TOPIC4_8HELP3)
#endif
#ifdef TOPIC4_8HELP4
        HELPTEXT(TOPIC4_8HELP4)
#endif
#ifdef TOPIC4_8HELP5
        HELPTEXT(TOPIC4_8HELP5)
#endif
#ifdef TOPIC4_8HELP6
        HELPTEXT(TOPIC4_8HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_8HELP1 - overall  */


#ifdef TOPIC4_9HELP1
.in_com_hlp4_9
        defb    $7F
        HELPTEXT(TOPIC4_9HELP1)
#ifdef TOPIC4_9HELP2
        HELPTEXT(TOPIC4_9HELP2)
#endif
#ifdef TOPIC4_9HELP3
        HELPTEXT(TOPIC4_9HELP3)
#endif
#ifdef TOPIC4_9HELP4
        HELPTEXT(TOPIC4_9HELP4)
#endif
#ifdef TOPIC4_9HELP5
        HELPTEXT(TOPIC4_9HELP5)
#endif
#ifdef TOPIC4_9HELP6
        HELPTEXT(TOPIC4_9HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_9HELP1 - overall  */


#ifdef TOPIC4_10HELP1
.in_com_hlp4_10
        defb    $7F
        HELPTEXT(TOPIC4_10HELP1)
#ifdef TOPIC4_10HELP2
        HELPTEXT(TOPIC4_10HELP2)
#endif
#ifdef TOPIC4_10HELP3
        HELPTEXT(TOPIC4_10HELP3)
#endif
#ifdef TOPIC4_10HELP4
        HELPTEXT(TOPIC4_10HELP4)
#endif
#ifdef TOPIC4_10HELP5
        HELPTEXT(TOPIC4_10HELP5)
#endif
#ifdef TOPIC4_10HELP6
        HELPTEXT(TOPIC4_10HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_10HELP1 - overall  */


#ifdef TOPIC4_11HELP1
.in_com_hlp4_11
        defb    $7F
        HELPTEXT(TOPIC4_11HELP1)
#ifdef TOPIC4_11HELP2
        HELPTEXT(TOPIC4_11HELP2)
#endif
#ifdef TOPIC4_11HELP3
        HELPTEXT(TOPIC4_11HELP3)
#endif
#ifdef TOPIC4_11HELP4
        HELPTEXT(TOPIC4_11HELP4)
#endif
#ifdef TOPIC4_11HELP5
        HELPTEXT(TOPIC4_11HELP5)
#endif
#ifdef TOPIC4_11HELP6
        HELPTEXT(TOPIC4_11HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_11HELP1 - overall  */


#ifdef TOPIC4_12HELP1
.in_com_hlp4_12
        defb    $7F
        HELPTEXT(TOPIC4_12HELP1)
#ifdef TOPIC4_12HELP2
        HELPTEXT(TOPIC4_12HELP2)
#endif
#ifdef TOPIC4_12HELP3
        HELPTEXT(TOPIC4_12HELP3)
#endif
#ifdef TOPIC4_12HELP4
        HELPTEXT(TOPIC4_12HELP4)
#endif
#ifdef TOPIC4_12HELP5
        HELPTEXT(TOPIC4_12HELP5)
#endif
#ifdef TOPIC4_12HELP6
        HELPTEXT(TOPIC4_12HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_12HELP1 - overall  */


#ifdef TOPIC4_13HELP1
.in_com_hlp4_13
        defb    $7F
        HELPTEXT(TOPIC4_13HELP1)
#ifdef TOPIC4_13HELP2
        HELPTEXT(TOPIC4_13HELP2)
#endif
#ifdef TOPIC4_13HELP3
        HELPTEXT(TOPIC4_13HELP3)
#endif
#ifdef TOPIC4_13HELP4
        HELPTEXT(TOPIC4_13HELP4)
#endif
#ifdef TOPIC4_13HELP5
        HELPTEXT(TOPIC4_13HELP5)
#endif
#ifdef TOPIC4_13HELP6
        HELPTEXT(TOPIC4_13HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_13HELP1 - overall  */


#ifdef TOPIC4_14HELP1
.in_com_hlp4_14
        defb    $7F
        HELPTEXT(TOPIC4_14HELP1)
#ifdef TOPIC4_14HELP2
        HELPTEXT(TOPIC4_14HELP2)
#endif
#ifdef TOPIC4_14HELP3
        HELPTEXT(TOPIC4_14HELP3)
#endif
#ifdef TOPIC4_14HELP4
        HELPTEXT(TOPIC4_14HELP4)
#endif
#ifdef TOPIC4_14HELP5
        HELPTEXT(TOPIC4_14HELP5)
#endif
#ifdef TOPIC4_14HELP6
        HELPTEXT(TOPIC4_14HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_14HELP1 - overall  */


#ifdef TOPIC4_15HELP1
.in_com_hlp4_15
        defb    $7F
        HELPTEXT(TOPIC4_15HELP1)
#ifdef TOPIC4_15HELP2
        HELPTEXT(TOPIC4_15HELP2)
#endif
#ifdef TOPIC4_15HELP3
        HELPTEXT(TOPIC4_15HELP3)
#endif
#ifdef TOPIC4_15HELP4
        HELPTEXT(TOPIC4_15HELP4)
#endif
#ifdef TOPIC4_15HELP5
        HELPTEXT(TOPIC4_15HELP5)
#endif
#ifdef TOPIC4_15HELP6
        HELPTEXT(TOPIC4_15HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_15HELP1 - overall  */


#ifdef TOPIC4_16HELP1
.in_com_hlp4_16
        defb    $7F
        HELPTEXT(TOPIC4_16HELP1)
#ifdef TOPIC4_16HELP2
        HELPTEXT(TOPIC4_16HELP2)
#endif
#ifdef TOPIC4_16HELP3
        HELPTEXT(TOPIC4_16HELP3)
#endif
#ifdef TOPIC4_16HELP4
        HELPTEXT(TOPIC4_16HELP4)
#endif
#ifdef TOPIC4_16HELP5
        HELPTEXT(TOPIC4_16HELP5)
#endif
#ifdef TOPIC4_16HELP6
        HELPTEXT(TOPIC4_16HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_16HELP1 - overall  */


#ifdef TOPIC4_17HELP1
.in_com_hlp4_17
        defb    $7F
        HELPTEXT(TOPIC4_17HELP1)
#ifdef TOPIC4_17HELP2
        HELPTEXT(TOPIC4_17HELP2)
#endif
#ifdef TOPIC4_17HELP3
        HELPTEXT(TOPIC4_17HELP3)
#endif
#ifdef TOPIC4_17HELP4
        HELPTEXT(TOPIC4_17HELP4)
#endif
#ifdef TOPIC4_17HELP5
        HELPTEXT(TOPIC4_17HELP5)
#endif
#ifdef TOPIC4_17HELP6
        HELPTEXT(TOPIC4_17HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_17HELP1 - overall  */


#ifdef TOPIC4_18HELP1
.in_com_hlp4_18
        defb    $7F
        HELPTEXT(TOPIC4_18HELP1)
#ifdef TOPIC4_18HELP2
        HELPTEXT(TOPIC4_18HELP2)
#endif
#ifdef TOPIC4_18HELP3
        HELPTEXT(TOPIC4_18HELP3)
#endif
#ifdef TOPIC4_18HELP4
        HELPTEXT(TOPIC4_18HELP4)
#endif
#ifdef TOPIC4_18HELP5
        HELPTEXT(TOPIC4_18HELP5)
#endif
#ifdef TOPIC4_18HELP6
        HELPTEXT(TOPIC4_18HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_18HELP1 - overall  */


#ifdef TOPIC4_19HELP1
.in_com_hlp4_19
        defb    $7F
        HELPTEXT(TOPIC4_19HELP1)
#ifdef TOPIC4_19HELP2
        HELPTEXT(TOPIC4_19HELP2)
#endif
#ifdef TOPIC4_19HELP3
        HELPTEXT(TOPIC4_19HELP3)
#endif
#ifdef TOPIC4_19HELP4
        HELPTEXT(TOPIC4_19HELP4)
#endif
#ifdef TOPIC4_19HELP5
        HELPTEXT(TOPIC4_19HELP5)
#endif
#ifdef TOPIC4_19HELP6
        HELPTEXT(TOPIC4_19HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_19HELP1 - overall  */


#ifdef TOPIC4_20HELP1
.in_com_hlp4_20
        defb    $7F
        HELPTEXT(TOPIC4_20HELP1)
#ifdef TOPIC4_20HELP2
        HELPTEXT(TOPIC4_20HELP2)
#endif
#ifdef TOPIC4_20HELP3
        HELPTEXT(TOPIC4_20HELP3)
#endif
#ifdef TOPIC4_20HELP4
        HELPTEXT(TOPIC4_20HELP4)
#endif
#ifdef TOPIC4_20HELP5
        HELPTEXT(TOPIC4_20HELP5)
#endif
#ifdef TOPIC4_20HELP6
        HELPTEXT(TOPIC4_20HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_20HELP1 - overall  */


#ifdef TOPIC4_21HELP1
.in_com_hlp4_21
        defb    $7F
        HELPTEXT(TOPIC4_21HELP1)
#ifdef TOPIC4_21HELP2
        HELPTEXT(TOPIC4_21HELP2)
#endif
#ifdef TOPIC4_21HELP3
        HELPTEXT(TOPIC4_21HELP3)
#endif
#ifdef TOPIC4_21HELP4
        HELPTEXT(TOPIC4_21HELP4)
#endif
#ifdef TOPIC4_21HELP5
        HELPTEXT(TOPIC4_21HELP5)
#endif
#ifdef TOPIC4_21HELP6
        HELPTEXT(TOPIC4_21HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_21HELP1 - overall  */


#ifdef TOPIC4_22HELP1
.in_com_hlp4_22
        defb    $7F
        HELPTEXT(TOPIC4_22HELP1)
#ifdef TOPIC4_22HELP2
        HELPTEXT(TOPIC4_22HELP2)
#endif
#ifdef TOPIC4_22HELP3
        HELPTEXT(TOPIC4_22HELP3)
#endif
#ifdef TOPIC4_22HELP4
        HELPTEXT(TOPIC4_22HELP4)
#endif
#ifdef TOPIC4_22HELP5
        HELPTEXT(TOPIC4_22HELP5)
#endif
#ifdef TOPIC4_22HELP6
        HELPTEXT(TOPIC4_22HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_22HELP1 - overall  */


#ifdef TOPIC4_23HELP1
.in_com_hlp4_23
        defb    $7F
        HELPTEXT(TOPIC4_23HELP1)
#ifdef TOPIC4_23HELP2
        HELPTEXT(TOPIC4_23HELP2)
#endif
#ifdef TOPIC4_23HELP3
        HELPTEXT(TOPIC4_23HELP3)
#endif
#ifdef TOPIC4_23HELP4
        HELPTEXT(TOPIC4_23HELP4)
#endif
#ifdef TOPIC4_23HELP5
        HELPTEXT(TOPIC4_23HELP5)
#endif
#ifdef TOPIC4_23HELP6
        HELPTEXT(TOPIC4_23HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_23HELP1 - overall  */


#ifdef TOPIC4_24HELP1
.in_com_hlp4_24
        defb    $7F
        HELPTEXT(TOPIC4_24HELP1)
#ifdef TOPIC4_24HELP2
        HELPTEXT(TOPIC4_24HELP2)
#endif
#ifdef TOPIC4_24HELP3
        HELPTEXT(TOPIC4_24HELP3)
#endif
#ifdef TOPIC4_24HELP4
        HELPTEXT(TOPIC4_24HELP4)
#endif
#ifdef TOPIC4_24HELP5
        HELPTEXT(TOPIC4_24HELP5)
#endif
#ifdef TOPIC4_24HELP6
        HELPTEXT(TOPIC4_24HELP6)
#endif
        defb    0               ;end marker
#endif /* TOPIC4_24HELP1 - overall  */
