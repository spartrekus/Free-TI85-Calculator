/***************************************************************
 *		TextInfDB.h
 *			Header for Rex addin program.
 ***************************************************************/
#ifndef TEXTINFDB_H
#define TEXTINFDB_H


	enum {
		TEXTINF_RECID = 1,
		TEXTINF_TOTAL_LINE,
		TEXTINF_TOTAL_BYTE,
		TEXTINF_DATA
	};
	
	enum {
		IDX_TEXTINF_RECID = 1
	};

#endif


