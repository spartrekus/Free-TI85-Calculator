#ifndef _FLTK_H
#define _FLTK_H

void fltk_init(int * argcp, char ***argvp, Z80 * cpu);
void fltk_run(Z80 * p);

#endif
