/*
 * Headerfile for ABC80 specific stuff
 *
 * $Id: abc80.h,v 1.2 2007/11/02 09:31:39 stefano Exp $
 */

#ifndef __ABC80_H__
#define __ABC80_H__

#include <sys/types.h>


/////////////
// GRAPHICS
/////////////

// Invert graphics display
extern void  __LIB__ abc_inv ();


#endif
