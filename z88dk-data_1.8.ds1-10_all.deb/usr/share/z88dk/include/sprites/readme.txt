Header files for each hardware API for all platforms go here.
Library code for the hardware API is already included in the
platform's default library (this means you do not need to
link to anything extra to use the API).

Header files for a software sprite engine are copied here
when the software sprite engine is configured and made.
