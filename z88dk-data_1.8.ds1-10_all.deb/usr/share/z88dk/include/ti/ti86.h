/* Control file for include Ti86 related things */

/* $Id: ti86.h,v 1.1 2007/11/16 14:52:45 stefano Exp $ */

#ifndef __TICALC_H__
#define __TICALC_H__

#endif
