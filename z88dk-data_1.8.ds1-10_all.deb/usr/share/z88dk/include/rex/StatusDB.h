/***************************************************************
 *		StatusDB.h
 *			Header for Rex addin program.
 ***************************************************************/
#ifndef STATUSDB_H
#define STATUSDB_H

	enum {
		STATUS_RECID = 1,
		STATUS_STATUS
	};
	enum {
		IDX_STATUS_RECID = 1
	};


	#define	REX_NEW		1
	#define	REX_MODIFIED	2
	#define	REX_DELETED	3

#endif


