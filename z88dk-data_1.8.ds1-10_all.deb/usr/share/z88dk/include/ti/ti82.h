/* Control file for include Ti82 related things */

/* $Id: ti82.h,v 1.1 2007/11/16 14:52:45 stefano Exp $ */

#ifndef __TICALC_H__
#define __TICALC_H__

#endif
