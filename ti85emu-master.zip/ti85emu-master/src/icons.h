#ifndef _ICONS_H
#define _ICONS_H

#include "Xpm/f1.xpm"
#include "Xpm/f2.xpm"
#include "Xpm/f3.xpm"
#include "Xpm/f4.xpm"
#include "Xpm/f5.xpm"

#include "Xpm/_2nd.xpm"
#include "Xpm/exit.xpm"
#include "Xpm/more.xpm"
#include "Xpm/left.xpm"
#include "Xpm/up.xpm"

#include "Xpm/alpha.xpm"
#include "Xpm/xvar.xpm"
#include "Xpm/del.xpm"
#include "Xpm/down.xpm"
#include "Xpm/right.xpm"

#include "Xpm/graph.xpm"
#include "Xpm/stat.xpm"
#include "Xpm/prgm.xpm"
#include "Xpm/custom.xpm"
#include "Xpm/clear.xpm"

#include "Xpm/log.xpm"
#include "Xpm/sin.xpm"
#include "Xpm/cos.xpm"
#include "Xpm/tan.xpm"
#include "Xpm/powerby.xpm"

#include "Xpm/ln.xpm"
#include "Xpm/ee.xpm"
#include "Xpm/parleft.xpm"
#include "Xpm/parright.xpm"
#include "Xpm/div.xpm"

#include "Xpm/power2.xpm"
#include "Xpm/seven.xpm"
#include "Xpm/eight.xpm"
#include "Xpm/nine.xpm"
#include "Xpm/mul.xpm"

#include "Xpm/comma.xpm"
#include "Xpm/four.xpm"
#include "Xpm/five.xpm"
#include "Xpm/six.xpm"
#include "Xpm/minus.xpm"

#include "Xpm/sto.xpm"
#include "Xpm/one.xpm"
#include "Xpm/two.xpm"
#include "Xpm/three.xpm"
#include "Xpm/plus.xpm"

#include "Xpm/on.xpm"
#include "Xpm/zero.xpm"
#include "Xpm/dot.xpm"
#include "Xpm/sign.xpm"
#include "Xpm/enter.xpm"

#endif
