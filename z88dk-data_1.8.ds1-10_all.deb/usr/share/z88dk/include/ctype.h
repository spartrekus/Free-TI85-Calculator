#ifndef __CTYPE_H__
#define __CTYPE_H__


extern int __LIB__ __FASTCALL__ isalpha(int);
extern int __LIB__ __FASTCALL__ isalnum(int);
extern int __LIB__ __FASTCALL__ isascii(int);
extern int __LIB__ __FASTCALL__ iscntrl(int);
extern int __LIB__ __FASTCALL__ isdigit(int);
extern int __LIB__ __FASTCALL__ isgraph(int);
extern int __LIB__ __FASTCALL__ isupper(int);
extern int __LIB__ __FASTCALL__ islower(int);
extern int __LIB__ __FASTCALL__ isprint(int);
extern int __LIB__ __FASTCALL__ ispunct(int);
extern int __LIB__ __FASTCALL__ isspace(int);
extern int __LIB__ __FASTCALL__ isxdigit(int);
extern int __LIB__ __FASTCALL__ toascii(int);
extern int __LIB__ __FASTCALL__ toupper(int);
extern int __LIB__ __FASTCALL__ tolower(int);


#endif
